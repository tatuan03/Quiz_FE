  import React, { useContext, useState, useEffect } from "react";
  import DataContext from "../context/dataContext";
  import Auth from "./Auth"; 
  import "./Start.css";
  const levelColors = ["#d4edda", "#d1ecf1", "#fff3cd", "#6f42c1", "#d63384"];

  const Start = ({ user, setUser }) => {
    const { startQuiz, showStart } = useContext(DataContext);
    const [showLoginPopup, setShowLoginPopup] = useState(false);

    useEffect(() => {
      const storedUser = localStorage.getItem("user");
      if (storedUser) {
        setUser(JSON.parse(storedUser));
      }
    }, [setUser]);

    const handleStartQuiz = (level) => {
      if (!user) {
        setShowLoginPopup(true); // Hiện popup nếu chưa đăng nhập
      } else {
        startQuiz(level);
      }
    };

    return (
      <div className="start-background">
        <section className="text-center   " style={{ display: showStart ? "block" : "none" }}>
          <div className="container">
            <div className="row align-items-center justify-content-center paddi">
            
                <h1 className="fw-bold mb-4">Select Quiz Level</h1>
                <div className="level-card-container">
                {["Beginner", "Intermediate", "Advanced", "Expert", "Impossible"].map((level, index) => (
              <div key={index} className="level-card" onClick={() => handleStartQuiz(index + 1)} style={{ backgroundColor: levelColors[index] }}>
              <h5 className="card-title fw-bold">{index + 1}.{level}</h5>
              <p className="card-text text-muted">Challenge yourself with {level} questions</p>
            </div>
))}
</div>
          
            </div>
          </div>

          {/* Popup đăng nhập */}
          {showLoginPopup && (
            <div className="modal d-block" style={{ backgroundColor: "rgba(0,0,0,0.5)" }}>
              <div className="modal-dialog">
                <div className="modal-content">
                  <div className="modal-header">
                    <h5 className="modal-title">Login Required</h5>
                    <button className="btn-close" onClick={() => setShowLoginPopup(false)}></button>
                  </div>
                  <div className="modal-body">
                    <Auth setUser={setUser} closeModal={() => setShowLoginPopup(false)} />
                  </div>
                </div>
              </div>
            </div>
          )}
        </section>
      </div>
    );
  };

  export default Start;
