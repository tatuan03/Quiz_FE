import React, { useContext, useState } from "react";
import {
  Modal,
  Button,
  Container,
  Navbar,
  Nav,
  Card
} from "react-bootstrap";
import Start from "./components/Start";
import Quiz from "./components/Quiz";
import Result from "./components/Result";
import Auth from "./components/Auth";
import { DataProvider } from "./context/dataContext";
import DataContext from "./context/dataContext";
import './App.css'


function AppContent({ user, setUser, showAuthModal, setShowAuthModal, handleLogout }) {
  const { showStart, showQuiz, showResult } = useContext(DataContext);

  return (
    <>
      {/* Navbar */}
      
      <Navbar className="navbara" >
        <Container>
          <Navbar.Brand href="/" className="fw-bold fs-2">🧠 Quiz App</Navbar.Brand>
          <Nav className="ms-auto d-flex align-items-center">
            {user ? (
              <>
                <span className="text-white me-2">
                  Welcome, <strong>{user.name}</strong>
                </span>
                <Button variant="outline-light" size="sm" onClick={handleLogout} >
                  Logout
                </Button>
              </>
            ) : (
              <Button
                onClick={() => setShowAuthModal(true)}
                className="custom-login-btn">
               Login
              </Button>
  
            )}
          </Nav>
        </Container>
      </Navbar>


      <Modal show={showAuthModal} onHide={() => setShowAuthModal(false)} centered>
        <Modal.Header closeButton>
          <Modal.Title>Login</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <Auth setUser={setUser} closeModal={() => setShowAuthModal(false)} />
        </Modal.Body>
      </Modal>
          {showStart && <Start user={user} setUser={setUser} />}
          {showQuiz && <Quiz />}
          {showResult && <Result />}
     
   
    </>
  );
}

function App() {
  const [user, setUser] = useState(null);
  const [showAuthModal, setShowAuthModal] = useState(false);

  const handleLogout = () => {
    setUser(null);
  };

  return (
    <DataProvider>
      <AppContent
        user={user}
        setUser={setUser}
        showAuthModal={showAuthModal}
        setShowAuthModal={setShowAuthModal}
        handleLogout={handleLogout}
      />
    </DataProvider>
  );
}

export default App;
